document.getElementById("voda").onclick = fuction(){
    alert("*150*00#");
}




